/****************************

BATCH #28
ABHIJIT LAL : 2009B3A7577P
UDBHAV PRASAD : 2009B4A7523P

PLCC Compiler Project STAGE 1

****************************/

#include <stdio.h>
#include "symbolTabDef.h"

extern Tables initSymTab();
extern Tables addToSymTab(symbolTab st, symTabEntry ste);
extern Tables loadTransTableAndSymTab();
