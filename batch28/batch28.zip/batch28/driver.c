/****************************

BATCH #28
ABHIJIT LAL : 2009B3A7577P
UDBHAV PRASAD : 2009B4A7523P

PLCC Compiler Project STAGE 1

****************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//#include "symbolTabDef.h"
#include "symbolTab.h"
//#include "parseTreeDef.h"
#include "grammarOps.h"
//#include "parseTree.h"
#include "lexerDef.h"


treeNode _parseInput(int PT[HASHTABLE_SIZE][STATES], Hashtable H, buffer B[], buffersize bk, FILE* fp);

char *filename;

int Term[53] = { 
    TK_ASSIGNOP,	// 1
	TK_COMMENT,
	TK_FIELDID,
	TK_ID,
	TK_NUM,
	TK_RNUM,
	TK_FUNID,
	TK_RECORDID,
	TK_WITH,
	TK_PARAMETERS,	// 10
	TK_END,
	TK_WHILE,
	TK_INT,
	TK_REAL,
	TK_TYPE,
	TK_MAIN,
	TK_GLOBAL,
	TK_PARAMETER,
	TK_LIST,
	TK_SQL,		// 20
	TK_SQR,
	TK_INPUT,
	TK_OUTPUT,
	TK_SEM,
	TK_COLON,
	TK_DOT,
	TK_ENDWHILE,
	TK_OP,
	TK_CL,
	TK_IF,		// 30
	TK_THEN,
	TK_ENDIF,
	TK_READ,
	TK_WRITE,
	TK_RETURN,
	TK_PLUS,
	TK_MINUS,
	TK_MUL,
	TK_DIV,
	TK_CALL,	// 40
	TK_RECORD,
	TK_ENDRECORD,
	TK_ELSE,
	TK_AND,
	TK_OR,
	TK_NOT,
	TK_LT,
	TK_LE,
	TK_EQ,
	TK_GT,	// 50
	TK_GE,
	TK_NE,
	TK_COMMA
};

int main(int argc, char** argv)
{
	if (argv[1] == NULL) {
		printf("Enter arguments in the format : %s <source_file> <parse_tree_out_file> <abstract_tree_out_file>\n", argv[0]);
		return 0;
	}
	
	FILE* fp;
	char bufferForG[GRAMBUF];
	char temp[30];
	int buffptr = 0;
	fp = fopen("grammar_n", "r");
	
	int i=0;
	
	Hashtable H;
	Lexeme *LHS;
	Lexeme *RHS;

	H = initializeHashtable(H, HASHTABLE_SIZE);
	
	int* firstSet;
	firstSet = (int*)malloc(FIRST_SET_SIZE*sizeof(int));
		
	while(!feof(fp))
	{
		fscanf(fp, "%s\n", bufferForG);
		if(bufferForG[buffptr]=='<')
		{
			buffptr++;
			do
			{
				temp[i++] = bufferForG[buffptr++];
				
			}while(bufferForG[buffptr] != '>');
			temp[i] = '\0';
			LHS = lexemize(temp);
			LHS->isTerminal = FALSE;
			strcpy(temp, "");
			i=0;
			
			Lexeme* RHShead=NULL;
			
			do
			{
				buffptr++;
				if(bufferForG[buffptr] == '<')
				{
					buffptr++;
					do
					{
						temp[i++] = bufferForG[buffptr++];
						
					}while(bufferForG[buffptr] != '>');
					
					temp[i] = '\0';
					RHS = lexemize(temp);
					RHS->isTerminal = FALSE;
					RHShead = addRHStoList(RHShead, *RHS);
					
					strcpy(temp, "");
					i=0;
				}
				else if(bufferForG[buffptr] == '[')
				{
					buffptr++;
					do
					{
						temp[i++] = bufferForG[buffptr++];
						
					}while(bufferForG[buffptr] != ']');	
					
					temp[i] = '\0';
					RHS = lexemize(temp);
					RHS->isTerminal = TRUE;
					RHShead = addRHStoList(RHShead, *RHS);
					strcpy(temp, "");
					i=0;
				}

			}while(bufferForG[buffptr]!= '\0');

			H = addLexemetoTable(H, *LHS, RHShead, HASHTABLE_SIZE);
			
		}
		buffptr++;
		strcpy(bufferForG, "");
		buffptr = 0;
	}
	fclose(fp);

	Lexeme* Z;
	char endtok[10];
	strcpy(endtok, "TK_END");
	int k, l;
	int ParseTable[HASHTABLE_SIZE][STATES];
	int index;
	initializeParseTable(ParseTable);
	Lexeme* lex;
	
	int* firstset = (int*)malloc(FIRST_SET_SIZE*sizeof(int));
	int* follset = (int*)malloc(FIRST_SET_SIZE*sizeof(int));
	for(k=0; k<HASHTABLE_SIZE; k++)
	{
		if(strcmp(H[k].lexemeName, "") == 0)
			continue;
		else 
			lex = lexemize(H[k].lexemeName);

		for(l=0; l<53; l++)
		{
			populateParseTable(ParseTable, H, Term[l], *lex);
		}
	}
	
	FILE* fp1 = fopen("LAL", "w");
	printParseTable(ParseTable, fp1);
	
	filename = (char*)malloc(NAMELEN*sizeof(char));
	strcpy(filename, argv[1]);
	
	Tables T = loadTransTableAndSymTab();
	
	buffer B[2] = {NULL, NULL};
	buffersize bk = BUF_SIZE;
	
	for (i=0; i<2; ++i) {
		B[i] = (buffer)malloc(bk*SIZE);
	}
	
	FILE* dfaf = fopen("finale_dfa_more_changes.csv", "r");
	if (!dfaf) {
		printf("Finite automata file MISSING\n");
		return;
	}

	loadTransTable(dfaf);
	fclose(dfaf);
	
	FILE* _fp = fopen(argv[1], "r");
	
	if (_fp == NULL) {
		printf("Source file does not exist!\n");
		return 0;
	}

	int x;
	int* first_set; Lexeme* le;
	le = lexemize("otherStmts");
	first_set = (int*)malloc(FIRST_SET_SIZE*sizeof(int)); 
	treeNode root = initParseTree("program");
	Stack s = initStack();
	root = _parseInput(ParseTable, H, B, bk, _fp);
	
	fclose(_fp);
	
	Hashtable ASTtable = NULL;
	FILE* fp_ast = fopen("ast_rules", "r");

	int buf_ctr = 0;
	strcpy(temp, "");
	i=0;
	char tchar;
	ASTtable = initializeHashtable(ASTtable, HASHTABLE_SIZE);
	
	while(!feof(fp_ast))
	{
		char bufferforAST[GRAMBUF];
		buf_ctr = 0;
		fscanf(fp_ast, "%s\n", bufferforAST);
		if(bufferforAST[buf_ctr]=='<')
		{
			buf_ctr++;
			do
			{
				temp[i++] = bufferforAST[buf_ctr++];
				
			}while(bufferforAST[buf_ctr] != '>');
			
			temp[i] = '\0';
			LHS = lexemize(temp);
			strcpy(temp, "");
			i=0;
			Lexeme* Rhead=NULL;
			do
			{
				fscanf(fp_ast, "\t%s%c", temp, &tchar);
				if(tchar == EOF)
					break;
				RHS = lexemize(temp);
				Rhead = addRHStoList(Rhead, *RHS);
				strcpy(temp,"");
				i=0;
				//fp_ast--;
			}while(tchar!='\n');
			
			ASTtable = addLexemetoTable(ASTtable, *LHS, Rhead, HASHTABLE_SIZE);
		}
	}
	
	//printHash(ASTtable);
	//printHash(H);
	
	astNode astr = initAST("program", 0);
	astr = populateAST(root, ASTtable);
	

	int user, token;
	bool done = false;
	FILE* userfp = fopen(argv[1], "r");
	
	FILE* ptfp = fopen(argv[2], "w");
	if (ptfp == NULL) {
		printf("Enter arguments in the format : %s <source_file> <parse_tree_out_file> <abstract_tree_out_file>\n", argv[0]);
		return 0;
	}
	
	FILE* fp_AST = fopen(argv[3], "w");
	if(fp_AST == NULL)
	{
		printf("Enter arguments in the format : %s <source_file> <parse_tree_out_file> <abstract_tree_out_file>\n", argv[0]);
		return 0;
	}
	
	
	
	while(done == false) {
		printf("\nChoose an option :\n");
		printf("\n 1. Print tokens.\n 2. Print parse tree.\n 3. Print abstract syntax tree.\n 4. Quit\n\nYour choice : ");
		scanf("%d", &user);
		
		switch (user) {
		case 1:
			printf("\nToken List:\n\n");
			do {
				token = getNextToken(userfp, B, bk);
				printf("%s\n", reverseEnum(token));
			} while (token != -2 && token != -1);
			if (token != -1)
				printf("%s\n", endtok);
			fclose(userfp);
			break;
			
		case 2:
			printf("Parse Tree:\n");
			FILE* fp_parser = fopen(argv[2], "w");
			if(fp_parser == NULL)
			{
				printf("Please specify the file to print parse tree\n");
				break;
			}
			if (_done == 1)
				printf("Compiled successfully, Parse tree printed in file %s\n", argv[2]);
			fprintf(fp_parser, "%-10s %-20s%-20s\t\t\t%-20s%-15s\n", "LINE NO", "TOKEN", "parentNode symbol", "isLeafNode", "Node symbol"); 
			fprintf(fp_parser, "%s\n", "***********************************************************************************************");
			printParseTree2(root, fp_parser, 0);
			fclose(fp_parser);
			break;
			
		case 3:
			printf("Abstract Syntax Tree:\n");
			printf("\nSize in bytes of AST: %ld\n", sizeof(_astNode)*printAST(fp_AST, astr, 0));
			printf("AST printed in file %s\n", argv[3]);
			fclose(fp_AST);
			break;
			
		case 4:
			done = true;
			break;
			
		default:
			printf("\nChoose from 1-4 please!\n");
		}
	}
	
	return 0;
}
