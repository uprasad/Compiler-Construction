/****************************

BATCH #28
ABHIJIT LAL : 2009B3A7577P
UDBHAV PRASAD : 2009B4A7523P

PLCC Compiler Project STAGE 1

****************************/

#include <stdio.h>
#include "parserDef.h"

extern Stack push(Stack s, char* lex);
extern void printStack(Stack s);
extern Stack pop(Stack s);
extern char* top(Stack s);
extern bool isEmpty(Stack s);

extern int printParseTree(treeNode root, int c);
extern void printParseTree2(treeNode root, FILE* fp);
extern astNode addChild(astNode root, astNode child);
extern int printAST(astNode root, int c);
